<?php $__env->startSection('content'); ?>
    <div class="container-fluid flex-grow-1 container-p-y">
        <!-- Layout Demo -->
        <div class="layout-demo-wrapper">

            <div class="layout-demo-info">
                <div class="row">
                    <div class="col-xl-4">
                        <div class="card">
                            <div class="row no-gutters">
                                <div class="col-auto p-4">
                                    <img src="<?php echo e(asset('assets/img/file-icons/256/005-database.png')); ?>" class="img-fluid"
                                        width="75" alt="">
                                </div>
                                <div class="col">
                                    <div class="card-block px-2 py-4">
                                        <h1 class="card-title">
                                            22

                                        </h1>
                                        <hr>
                                        <p class="card-text">Total Berita</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="card">
                            <div class="row no-gutters">
                                <div class="col-auto p-4">
                                    <img src="<?php echo e(asset('assets/img/file-icons/256/006-record.png')); ?>" class="img-fluid"
                                        width="75" alt="">
                                </div>
                                <div class="col">
                                    <div class="carixzzZxsdzvccxzxz321`121`11`112321`d-block px-2 py-4">
                                        <h1 class="card-title">
                                            21
                                        </h1>
                                        <hr>
                                        <p class="card-text">Total Asprasi Rakyat</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="card">
                            <div class="row no-gutters">
                                <div class="col-auto p-4">
                                    <img src="<?php echo e(asset('assets/img/file-icons/256/003-interface.png')); ?>" class="img-fluid"
                                        width="75" alt="">
                                </div>
                                <div class="col">
                                    <div class="card-block px-2 py-4">
                                        <h1 class="card-title">
                                            10
                                        </h1>
                                        <hr>
                                        <p class="card-text">Aspirasi Belum Direspon</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ Layout Demo -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\Laravel-Apss\dasfo\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>