<?php $__env->startSection('header'); ?>
    <div class="appHeader no-border">
        <div class="left">
            <a href=" <?php echo e(url()->previous()); ?> " class="headerButton">
                <ion-icon name="chevron-back-outline" role="img" class="md hydrated" aria-label="chevron back outline">
                </ion-icon>
            </a>
        </div>
        <div class="pageTitle">Tulis Aspirasi</div>
        <div class="right">

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="appCapsule">
        <div class="section mt-2">
            <div class="wide-block pb-1 pt-1">

                <form method="POST" action=" <?php echo e(route('insert_forum')); ?> ">
                    <?php echo csrf_field(); ?>
                    <ul class="listview image-listview no-line no-space flush mb-2">
                        <li>
                            <div class="item">
                                <div class="icon-box bg-dark">
                                    <ion-icon name="eye-off-outline" role="img" class="md hydrated"
                                        aria-label="repeat outline"></ion-icon>
                                </div>
                                <div class="in">
                                    <div>Kirim sebagai anonim</div>
                                    <div class="custom-control custom-switch">
                                        <input name="anonim" type="checkbox" class="custom-control-input"
                                            id="customSwitch5">
                                        <label class="custom-control-label" for="customSwitch5"></label>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li id="input-name">
                            <div class="item">
                                <div class="icon-box bg-success">
                                    <ion-icon name="person-circle-outline" role="img" class="md hydrated"
                                        aria-label="mail outline"></ion-icon>
                                </div>
                                <div class="in">
                                    <div class="form-group basic">
                                        <div class="input-wrapper">
                                            <input name="name" type="text" class="form-control text-capitalize"
                                                placeholder="Masukkan nama Anda">
                                            <i class="clear-input">
                                                <ion-icon name="close-circle" role="img" class="md hydrated"
                                                    aria-label="close circle"></ion-icon>
                                            </i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                    </ul>
                    <?php $__errorArgs = ['aspiration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <textarea name="aspiration" id="editor"></textarea>

                    <button type="submit" class="btn btn-primary mr-1 mb-1 rounded mt-2">

                        <ion-icon name="send-outline" role="img" class="md hydrated" aria-label="mail outline">
                        </ion-icon>
                        Kirim
                    </button>
                </form>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        CKEDITOR.replace('editor', {
            filebrowserUploadUrl: "<?php echo e(route('uploadImage', ['_token' => csrf_token()])); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-css'); ?>
    <style>
        .ck.ck - editor__main>.ck - editor__editable: not(.ck - focused) {
            min - height: 300 px;
        }

        .ck - rounded - corners.ck.ck - editor__main>.ck - editor__editable,
        .ck.ck - editor__main>.ck - editor__editable.ck - rounded - corners {

            min - height: 300 px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\Laravel-Apss\dasfo\resources\views/forum/add.blade.php ENDPATH**/ ?>