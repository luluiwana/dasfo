
<?php $__env->startSection('header'); ?>
    <div class="appHeader no-border">
        <div class="left">
            <a href=" <?php echo e(url()->previous()); ?> " class="headerButton">
                <ion-icon name="chevron-back-outline" role="img" class="md hydrated" aria-label="chevron back outline">
                </ion-icon>
            </a>
        </div>
        <div class="pageTitle">Aspirasi Masyarakat</div>
        <div class="right">

        </div>
    </div>
    <div id="search" class="appHeader">
        <form class="search-form">
            <div class="form-group searchbox">
                <input type="text" class="form-control" placeholder="Cari...">
                <i class="input-icon">
                    <ion-icon name="search-outline" role="img" class="md hydrated" aria-label="search outline">
                    </ion-icon>
                </i>
                <a href="javascript:;" class="ml-1 close toggle-searchbox">
                    <ion-icon name="close-circle" role="img" class="md hydrated" aria-label="close circle"></ion-icon>
                </a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="appCapsule">
        <div class="section mt-2">
            <div class="card text-center bg-gradient">

                <div class="card-body">
                    <h5 class="h4  text-white">Suarakan aspirasi, aduan, harapan, dan usulan Anda!</h5>
                    <a href=" <?php echo e(route('addforum')); ?> " class="btn btn-success mr-1 mb-1 rounded mt-3 btn-lg">
                        <ion-icon name="mail-open-outline" role="img" class="md hydrated"
                            aria-label="mail-open-outline"></ion-icon>
                        Tulis Aspirasi
                    </a>
                </div>
            </div>
        </div>


        <div class="section mt-2">
            <?php $__currentLoopData = $aspirations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card bg-light mb-2">
                    <div class="card-body">

                        <div class="d-flex">
                            <div class="w-50">
                                <p class="card-title text-capitalize"> <?php echo e($item->name); ?> </p>
                            </div>
                            <div class="w-50">
                                <p class="card-text text-right"><small>
                                        <?php echo e(Carbon\Carbon::parse($item->created_at)->format('H:i . d-M-y ')); ?>

                                    </small></p>
                            </div>
                        </div>
                        <p class="card-text"> <?php echo $item->aspiration; ?> </p>

                        
                    </div>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <a href="#" class="button goTop show">
            <ion-icon name="arrow-up-outline" role="img" class="md hydrated" aria-label="arrow up outline"></ion-icon>
        </a>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\Laravel-Apss\dasfo\resources\views/forum/index.blade.php ENDPATH**/ ?>